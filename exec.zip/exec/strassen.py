import os
import sys

print("okay")
